# 『国語研日本語ウェブコーパス』 中納言搭載データ 語彙表 version 2022.02

## Description
本データは 2022年2月に公開された『国語研日本語ウェブコーパス』中納言
搭載データに基づく短単位語彙表である。空白・補助記号・記号も含む。
短単位は、語彙素・語彙素読み・品詞・語彙素細分類・語種の 5 つの組で
見出し語を特定した。

## Creator
国立国語研究所

## License
CC BY 4.0 https://creativecommons.org/licenses/by/4.0/deed.ja

## Credit
National Institute for Japanese Language and Linguistics (2022)
『国語研日本語ウェブコーパス』 中納言搭載データ 語彙表 version 2022.02

## Format
- NWJC_frequencylist_suw_ver2022_02.tsv
- 106,763行(ヘッダ行を含む)、UTF-8、タブ区切り

|   | 見出し    | 摘要                                                    |
|---|-----------|---------------------------------------------------------|
| 1 | rank      | NWJC 中納言搭載データ上の順位                           |
| 2 | lForm     | 語彙素読み                                              |
| 3 | lemma     | 語彙素                                                  |
| 4 | pos       | 品詞                                                    |
| 5 | subLemma  | 語彙素細分類                                            |
| 6 | wType     | 語種                                                    |
| 7 | frequency | NWJC 中納言搭載データ上の頻度                           |
| 8 | pmw       | NWJC 中納言搭載データ上の相対頻度 (100万語あたりの頻度) |


